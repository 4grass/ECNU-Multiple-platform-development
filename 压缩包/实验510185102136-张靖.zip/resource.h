//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Resource.rc ʹ��
//
#define IDR_MENU1                       101
#define IDI_ICON1                       102
#define IDC_CURSOR1                     103
#define IDB_BITMAP1                     104
#define IDB_BITMAP2                     105
#define IDB_BITMAP3                     106
#define IDD_DIALOG1                     107
#define IDD_DIALOG2                     109
#define IDS_STRING111                   111
#define IDS_STRING112                   112
#define IDR_ACCELERATOR1                112
#define IDS_STRING113                   113
#define IDS_STRING114                   114
#define IDS_STRING115                   115
#define IDS_STRING116                   116
#define IDS_STRING117                   117
#define IDS_STRING118                   118
#define IDS_STRING119                   119
#define IDS_STRING120                   120
#define IDS_STRING121                   121
#define IDS_STRING122                   122
#define IDS_STRING123                   123
#define IDS_STRING124                   124
#define IDS_STRING125                   125
#define IDS_STRING126                   126
#define IDS_STRING127                   127
#define IDS_STRING128                   128
#define IDS_STRING129                   129
#define IDS_STRING130                   130
#define IDS_STRING131                   131
#define IDS_STRING132                   132
#define IDS_STRING133                   133
#define IDS_STRING134                   134
#define IDS_STRING135                   135
#define IDS_STRING136                   136
#define IDS_STRING137                   137
#define IDS_STRING138                   138
#define IDS_STRING139                   139
#define IDS_STRING140                   140
#define IDS_STRING141                   141
#define IDS_STRING142                   142
#define IDC_CHECK1                      1001
#define IDC_CHECK2                      1002
#define IDC_CHECK3                      1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_RADIO3                      1006
#define ID_40001                        40001
#define ID_40002                        40002
#define ID_40003                        40003
#define ID_40004                        40004
#define ID_40005                        40005
#define ID_40006                        40006
#define ID_40007                        40007
#define ID_Menu                         40008
#define ID_40009                        40009
#define ID_40010                        40010
#define ID_40011                        40011
#define ID_40012                        40012
#define ID_Menu40013                    40013
#define ID_40014                        40014
#define ID_ACCELERATOR40015             40015
#define ID_ACCELERATOR40016             40016
#define ID_ACCELERATOR40017             40017
#define ID_ACCELERATOR40018             40018
#define ID_ACCELERATOR40020             40020
#define ID_ACCELERATOR40022             40022
#define ID_ACCELERATOR40024             40024
#define ID_ACCELERATOR40025             40025
#define ID_ACCELERATOR40026             40026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40028
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
