//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Resource.rc ʹ��
//
#define ID_EEEE                         9292
#define IDR_ACCELERATOR1                104
#define IDR_MENU1                       105
#define IDI_FIRST                       1111
#define ID_EXIT                         1112
#define ID_TU1                          2000
#define ID_TU2                          2001
#define ID_TB                           2001
#define ID_TB1                          2001
#define ID_TB2                          2002
#define ID_TU3                          2003
#define ID_TB3                          2003
#define IDI_SECOND                      2222
#define ID_XS1                          3001
#define ID_XS2                          3002
#define ID_XS3                          3003
#define ID_XS4                          3004
#define IDI_THIRD                       3333
#define ID_CX                           4001
#define ID_FILE_EXIT                    40002
#define ID_EEEE                         40003
#define ID_40004                        40004
#define ID_40005                        40005
#define ID_40006                        40006
#define ID_40007                        40007
#define ID_40008                        40008
#define ID_40009                        40009
#define ID_40010                        40010
#define ID_40011                        40011
#define ID_40012                        40012
#define ID_40014                        40014
#define ID_40015                        40015
#define ID_                             40016
#define ID_Menu                         40019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40033
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
